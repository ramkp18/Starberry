<!doctype html>
<html lang="en">
 
	<head>		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Starberry</title>
		<link href="css/bootstrap.min.css" rel="stylesheet" />
		<script src="js/jquery-2.1.1.min.js" crossorigin="anonymous"></script>
		<script src="js/bootstrap.min.js" crossorigin="anonymous"></script>
		<style>
			.clear{padding-bottom:10px;clear:both}
			.text-wrap{word-wrap: break-word;}
		</style>
	</head>

	<body>
		<?php 
			include_once 'config/database.php';
			$database = new Database();
			$db = $database->getConnection();	
		?>
		<div class="container">
			<div class="row">
				<div class="clear"></div>
				<div class="clear"></div>
				<div class="clear"></div>
				<div class="col-sm-2">
					<select name="class" class="form-control">
						<option value="people">people</option>
						<option value="planets">Planets</option>
						<option value="starships">Starships</option>
						<option value="vehicles">Vehicles</option>
					</select>
				</div>
				<div class="col-sm-2">
					<select name="operation" class="form-control" >						
						<option value="C">Create</option>
						<option value="R">Read</option>						
						<option value="U">Update</option>
						<option value="D">Delete</option>
					</select>
				</div>
				<div class="col-sm-8">
					<div class="input-group">
						<input type="text" class="form-control" placeholder="1" name="textSent" pattern="[0-9]+">
						<div class="input-group-btn">
							<button class="btn btn-primary" type="button" name="btnDoAction"> Click</button>
						</div>
					</div>
				</div>
				<div class="clear"></div>
				
				<form class="hide" id="peopleUpdate">
					<div class="form-group">
						<label  class="col-sm-2 control-label">People Field Name</label>
						<div class="col-sm-2">
							<select name="field" class="form-control">
								<?php 
									$sqlQuery = "DESCRIBE people";
									$stmt = $db->query($sqlQuery);
									$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
									foreach($result as $row){
										if($row['Field'] != 'people_id' && $row['Field'] != 'id'){
								?>
									<option value="<?php echo $row['Field']?>"><?php echo $row['Field']?></option>
								<?php 
										}}
								?>
							</select>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-7">
							<input type="text" class="form-control" name="value" placeholder="Value">
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-1">
							<button class="btn btn-primary" type="button" name="btnUpadte"> Update</button>
						</div>
					</div>
				</form>
				
				<form class="hide" id="planetsUpdate">
					<div class="form-group">
						<label  class="col-sm-2 control-label">Planet Field Name</label>
						<div class="col-sm-2">
							<select name="field" class="form-control">
								<?php 
									$sqlQuery = "DESCRIBE planets";
									$stmt = $db->query($sqlQuery);
									$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
									foreach($result as $row){
										if($row['Field'] != 'planet_id' && $row['Field'] != 'id'){
								?>
									<option value="<?php echo $row['Field']?>"><?php echo $row['Field']?></option>
								<?php 
										}}
								?>
							</select>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-7">
							<input type="text" class="form-control" name="value" placeholder="Value">
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-1">
							<button class="btn btn-primary" type="button" name="btnUpadte"> Update</button>
						</div>
					</div>
				</form>
				
				<form class="hide" id="starshipsUpdate">
					<div class="form-group">
						<label  class="col-sm-2 control-label">Starships Field Name</label>
						<div class="col-sm-2">
							<select name="field" class="form-control">
								<?php 
									$sqlQuery = "DESCRIBE starships ";
									$stmt = $db->query($sqlQuery);
									$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
									foreach($result as $row){
										if($row['Field'] != 'starship_id'  && $row['Field'] != 'id'){
								?>
									<option value="<?php echo $row['Field']?>"><?php echo $row['Field']?></option>
								<?php 
										}}
								?>
							</select>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-7">
							<input type="text" class="form-control" name="value" placeholder="Value">
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-1">
							<button class="btn btn-primary" type="button" name="btnUpadte"> Update</button>
						</div>
					</div>
				</form>
				
				<form class="hide" id="vehiclesUpdate">
					<div class="form-group">
						<label  class="col-sm-2 control-label">Vehicles Field Name</label>
						<div class="col-sm-2">
							<select name="field" class="form-control">
								<?php 
									$sqlQuery = "DESCRIBE vehicles ";
									$stmt = $db->query($sqlQuery);
									$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
									foreach($result as $row){
										if($row['Field'] != 'vehicle_id'  && $row['Field'] != 'id'){
								?>
									<option value="<?php echo $row['Field']?>"><?php echo $row['Field']?></option>
								<?php 
										}}
								?>
							</select>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-7">
							<input type="text" class="form-control" name="value" placeholder="Value">
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-1">
							<button class="btn btn-primary" type="button" name="btnUpadte"> Update</button>
						</div>
					</div>
				</form>
				
				<div class="clear"></div>
				<div class="well well-sm hide text-wrap" id="resultPanel">
				
				</div>
			</div>
		</div>
	</body>
	<script>		
		$('select[name=operation]').on('change',function(){
			$('form[id$=Update],#resultPanel').addClass('hide');
			$('input[name=textSent]').val('');
		});
		$('button[name=btnDoAction]').click(function() {
			var ajaxurl = 'api/read.php?class=people';
			var phpClass = $('select[name=class]').val();
			var operation = $('select[name=operation]').val();
			
			if(operation == 'C'){
				ajaxurl = 'api/create.php?class='+phpClass;
			}
			if(operation == 'R' || operation == 'U'){
				ajaxurl = 'api/read.php?class='+phpClass;
			}
			/* if(operation == 'U'){
				ajaxurl = 'api/update.php?class='+phpClass;
			} */
			if(operation == 'D'){
				ajaxurl = 'api/delete.php?class='+phpClass;
			}
			if(operation != 'R' && !$('input[name=textSent]').val()){
				alert('please enter a numeric value');
				$('input[name=textSent]').focus();
			}else{
				$.ajax({
					url: ajaxurl,
					dataType: 'json',
					type: 'post',
					data: '&textSent='+$('input[name=textSent]').val(),
					beforeSend: function() {
						$('button[name=btnDoAction]').button('loading');
					},
					complete: function() {
						$('button[name=btnDoAction]').button('reset');
					},
					success: function(json) {									
						$('form[id$=Update]').addClass('hide');
						$('#resultPanel').removeClass('hide').html('<span class="text-success">Response:</span><div class="clear"></div><span class="text-danger">'+JSON.stringify(json)+'</span>');
						if(operation == 'U'){
							$('#'+$('select[name=class]').val()+'Update').removeClass('hide');
						}
					},
					error: function(xhr, ajaxOptions, thrownError) {
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">'+thrownError+'</span>');	
					}
				});
			}
		});
		
		$(document).delegate('button[name=btnUpadte]','click',function() {			
			var phpClass = $('select[name=class]').val();
			
			if(!$('input[name=textSent]').val()){
				alert('please enter a numeric value');
				$('input[name=textSent]').focus();
			}else{
				$.ajax({
					context: this,
					url: 'api/update.php?class='+phpClass,
					dataType: 'json',
					type: 'post',
					data: '&textSent='+$('input[name=textSent]').val()+'&field='+$('#'+$('select[name=class]').val()+'Update select[name=field]').val()+'&value='+$('#'+$('select[name=class]').val()+'Update input[name=value]').val(),
					beforeSend: function() {
						$(this).button('loading');
					},
					complete: function() {
						$(this).button('reset');
					},
					success: function(json) {									
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">'+JSON.stringify(json)+'</span>');					
					},
					error: function(xhr, ajaxOptions, thrownError) {
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">something went wrong!</span>');	
					}
				});
			}
		
		});
	</script>
</html>