<!doctype html>
<html lang="en">
 
	<head>		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Starberry</title>
		<link href="css/bootstrap.min.css" rel="stylesheet" />
		<script src="js/jquery-2.1.1.min.js" crossorigin="anonymous"></script>
		<script src="js/bootstrap.min.js" crossorigin="anonymous"></script>
		<style>
			.clear{padding-bottom:10px;clear:both}
			.text-wrap{word-wrap: break-word;}
		</style>
	</head>

	<body>
		<?php 
			include_once 'config/database.php';
			$database = new Database();
			$db = $database->getConnection();	
		?>
		<div class="container">
			<div class="row">
				<div class="clear"></div>
				<div class="clear"></div>
				<div class="clear"></div>
				<div class="col-sm-2">
					<select name="class" class="form-control">
						<option value="people">people</option>
						<option value="planets">Planets</option>
						<option value="starships">starships</option>
					</select>
				</div>
				<div class="col-sm-2">
					<select name="operation" class="form-control" onChange="(this.value == 'U' || this.value == 'R') ? $('#peopleUpdate').removeClass('hide') : $('#peopleUpdate').addClass('hide')">						
						<option value="R">Read</option>
						<option value="C">Create</option>
						<option value="U">Update</option>
						<option value="D">Delete</option>
					</select>
				</div>
				<div class="col-sm-8">
					<div class="input-group">
						<input type="text" class="form-control" placeholder="1" name="textSent" pattern="[0-9]+">
						<div class="input-group-btn">
							<button class="btn btn-primary" type="button" name="btnDoAction"> Click</button>
						</div>
					</div>
				</div>
				<div class="clear"></div>
				
				<form class="" id="peopleUpdate">
					<div class="form-group">
						<label  class="col-sm-2 control-label">Field Name</label>
						<div class="col-sm-2">
							<select name="field" class="form-control">
								<?php 
									$sqlQuery = "DESCRIBE people";
									$stmt = $db->query($sqlQuery);
									$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
									foreach($result as $row){
										if($row['Field'] != 'people_id'){
								?>
									<option value="<?php echo $row['Field']?>"><?php echo $row['Field']?></option>
								<?php 
										}}
								?>
							</select>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-7">
							<input type="text" class="form-control" name="value" placeholder="Value">
						</div>
					</div>
					<div class="form-group">						
						<div class="col-sm-1">
							<button class="btn btn-primary" type="button" name="btnUpadte"> Update</button>
						</div>
					</div>
				</form>
				
				<div class="clear"></div>
				<div class="well well-sm hide text-wrap" id="resultPanel">
				
				</div>
			</div>
		</div>
	</body>
	<script>		
		$('button[name=btnDoAction]').click(function() {
			var ajaxurl = 'api/read.php?class=people';
			var phpClass = $('select[name=class]').val();
			var operation = $('select[name=operation]').val();
			
			if(operation == 'C'){
				ajaxurl = 'api/create.php?class='+phpClass;
			}
			if(operation == 'R'){
				ajaxurl = 'api/read.php?class='+phpClass;
			}
			if(operation == 'U'){
				ajaxurl = 'api/update.php?class='+phpClass;
			}
			if(operation == 'D'){
				ajaxurl = 'api/delete.php?class='+phpClass;
			}
			if(operation != 'R' && !$('input[name=textSent]').val()){
				alert('please enter a numeric value');
				$('input[name=textSent]').focus();
			}else{
				$.ajax({
					url: ajaxurl,
					dataType: 'json',
					type: 'post',
					data: '&textSent='+$('input[name=textSent]').val(),
					beforeSend: function() {
						$('button[name=btnDoAction]').button('loading');
					},
					complete: function() {
						$('button[name=btnDoAction]').button('reset');
					},
					success: function(json) {									
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">'+JSON.stringify(json)+'</span>');					
					},
					error: function(xhr, ajaxOptions, thrownError) {
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">something went wrong!</span>');	
					}
				});
			}
		});
		
		$('button[name=btnUpadte]').click(function() {			
			if($('select[name=class]').val() != 'people'){
				alert('Page under contruction.. Please select people.');
				$('select[name=class]').focus();
			}
			else if(!$('input[name=textSent]').val()){
				alert('please enter a numeric value');
				$('input[name=textSent]').focus();
			}else{
				$.ajax({
					url: 'api/update.php?class=people',
					dataType: 'json',
					type: 'post',
					data: '&textSent='+$('input[name=textSent]').val()+'&field='+$('select[name=field]').val()+'&value='+$('input[name=value]').val(),
					beforeSend: function() {
						$('button[name=btnUpadte]').button('loading');
					},
					complete: function() {
						$('button[name=btnUpadte]').button('reset');
					},
					success: function(json) {									
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">'+JSON.stringify(json)+'</span>');					
					},
					error: function(xhr, ajaxOptions, thrownError) {
						$('#resultPanel').removeClass('hide').html('<span class="text-danger">something went wrong!</span>');	
					}
				});
			}
		
		});
	</script>
</html>