<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';   
    
    $database = new Database();
    $db = $database->getConnection();      
    
    $id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
	$class = isset($_GET["class"]) ? $_GET["class"] : "people";
    
	if($class == "people"){
		include_once '../class/people.php';
		$item = new People($db);    
		$item->id = $id;
		
		if($item->deletePeople()){
			echo json_encode("People deleted successfully.");
		} else{
			echo json_encode("Data could not be deleted");
		}
	}
	if($class == "planets"){
		include_once '../class/planets.php';
		
		$item = new Planets($db);    
		$item->id = $id;
		
		if($item->deletePlanet()){
			echo json_encode("Planet deleted successfully.");
		} else{
			echo json_encode("Data could not be deleted");
		}
	}
	
	if($class == "starships"){
		include_once '../class/starships.php';
		
		$item = new Starships($db);    
		$item->id = $id;
		
		if($item->deleteStarship()){
			echo json_encode("Starship deleted successfully.");
		} else{
			echo json_encode("Data could not be deleted");
		}
	}
	
	if($class == "vehicles"){
		include_once '../class/vehicles.php';
		
		$item = new Vehicles($db);    
		$item->id = $id;
		
		if($item->deleteVehicle()){
			echo json_encode("Vehicle deleted successfully.");
		} else{
			echo json_encode("Data could not be deleted");
		}
	}
?>