<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    

    $database = new Database();
    $db = $database->getConnection();	
	
	$class = isset($_GET["class"]) ? $_GET["class"] : "people";
	$id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;

	if($class == "people"){
		include_once '../class/people.php';
		$items = new People($db);
		if($id == 0){
			$stmt = $items->getPeoples();
			$itemCount = $stmt->rowCount();

			if($itemCount > 0){
				
				$peopleArr = array();
				$peopleArr["body"] = array();
				$peopleArr["itemCount"] = $itemCount;

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					extract($row);
					$e = array(
						"people_id" => $people_id,
						"name" => $name,
						"height" => $height,
						"mass" => $mass,
						"hair_color" => $hair_color,
						"skin_color" => $skin_color,
						"eye_color" => $eye_color,
						"birth_year" => $birth_year,
						"gender" => $gender,
						"homeworld" => $homeworld,
						"films" => $films,
						"species" => $species,
						"vehicles" => $vehicles,
						"starships" => $starships,
						"created" => $created,
						"edited" => $edited,
						"url" => $url
					);

					array_push($peopleArr["body"], $e);
				}
				echo json_encode($peopleArr);
			}

			else{				
				echo json_encode(
					array("message" => "No record found.")
				);
			}
		}else{
			$items->id = isset($_POST["textSent"]) ? $_POST["textSent"] : 0;
			$items->getSinglePeople();

			if($items->name != null){
				// create array
				$peo_arr = array(
					"id" =>  $items->people_id,
					"name" => $items->name,
					"height" => $items->height,
					"mass" => $items->mass,
					"hair_color" => $items->hair_color,
					"skin_color" => $items->skin_color,
					"eye_color" => $items->eye_color,
					"birth_year" => $items->birth_year,
					"gender" => $items->gender,
					"homeworld" => $items->homeworld,
					"films" => $items->films,
					"species" => $items->species,
					"vehicles" => $items->vehicles,
					"starships" => $items->starships,
					"created" => $items->created,
					"edited" => $items->edited,
					"url" => $items->url
				);
			  
				http_response_code(200);
				echo json_encode($peo_arr);
			}
			  
			else{				
				echo json_encode("People not found.");
			}
		}
	}
	
	if($class == "planets"){
		include_once '../class/planets.php';
		$items = new Planets($db);
		if($id == 0){
			$stmt = $items->getPlanets();
			$itemCount = $stmt->rowCount();
			if($itemCount > 0){
				
				$planetArr = array();
				$planetArr["body"] = array();
				$planetArr["itemCount"] = $itemCount;

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					extract($row);
					$e = array(
						"planet_id " => $planet_id ,
						"name" => $name,
						"rotation_period" => $rotation_period,
						"orbital_period" => $orbital_period,
						"diameter" => $diameter,
						"climate" => $climate,
						"gravity" => $gravity,
						"terrain" => $terrain,
						"surface_water" => $surface_water,
						"population" => $population,
						"residents" => $residents,
						"films" => $films,
						"created" => $created,
						"edited" => $edited,
						"url" => $url
					);

					array_push($planetArr["body"], $e);
				}
				echo json_encode($planetArr);
			}

			else{				
				echo json_encode(
					array("message" => "No record found.")
				);
			}
		}else{
			$items->id = isset($_POST["textSent"]) ? $_POST["textSent"] : 0;
			$items->getSinglePlanet();

			if($items->name != null){
				// create array
				$peo_arr = array(
					"planet_id " =>  $items->planet_id ,
					"name" => $items->name,
					"rotation_period" => $items->rotation_period,
					"orbital_period" => $items->orbital_period,
					"diameter" => $items->diameter,
					"climate" => $items->climate,
					"gravity" => $items->gravity,
					"terrain" => $items->terrain,
					"surface_water" => $items->surface_water,
					"population" => $items->population,
					"residents" => $items->residents,
					"films" => $items->films,
					"created" => $items->created,
					"edited" => $items->edited,
					"url" => $items->url
				);
			  
				http_response_code(200);
				echo json_encode($peo_arr);
			}			  
			else{				
				echo json_encode("Planet not found.");
			}
		}
	}
	
?>