<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/people.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new People($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
    $item->id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
    $field = (isset($_POST["field"])) ? $_POST["field"] : "";
    $value = (isset($_POST["value"])) ? $_POST["value"] : "";
    
	if($field && $value){
		$item->field = $field;
		$item->value = $value;
		
		if($item->updatePeople()){
			echo json_encode("People data updated.");
		} else{
			echo json_encode("Data could not be updated");
	   }
	}
	else{
		echo json_encode("Something went wrong!");
   }
?>