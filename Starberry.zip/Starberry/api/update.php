<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    
    
    $database = new Database();
    $db = $database->getConnection();
    
	$class = isset($_GET["class"]) ? $_GET["class"] : "people";    
    $field = (isset($_POST["field"])) ? $_POST["field"] : "";
    $value = (isset($_POST["value"])) ? $_POST["value"] : "";
    
	if($field && $value){		
		if($class == "people"){
			include_once '../class/people.php';
			$item = new People($db);     
			$item->id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
			$item->field = $field;
			$item->value = $value;
		
			if($item->updatePeople()){
				echo json_encode("People data updated.");
			} else{
				echo json_encode("Data could not be updated");
			}
		}
		
		if($class == "planets"){
			include_once '../class/planets.php';
			$item = new Planets($db);     
			$item->id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
			$item->field = $field;
			$item->value = $value;
		
			if($item->updatePlanet()){
				echo json_encode("Planet data updated.");
			} else{
				echo json_encode("Data could not be updated");
			}
		}
		
		if($class == "starships"){
			include_once '../class/starships.php';
			$item = new Starships($db);     
			$item->id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
			$item->field = $field;
			$item->value = $value;
		
			if($item->updateStarship()){
				echo json_encode("Starship data updated.");
			} else{
				echo json_encode("Data could not be updated");
			}
		}
		
		if($class == "vehicles"){
			include_once '../class/vehicles.php';
			$item = new Vehicles($db);     
			$item->id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
			$item->field = $field;
			$item->value = $value;
		
			if($item->updateVehicle()){
				echo json_encode("Vehicle data updated.");
			} else{
				echo json_encode("Data could not be updated");
			}
		}
	}
	else{
		echo json_encode("Something went wrong!");
   }
?>