<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
   

    $database = new Database();
    $db = $database->getConnection();

    
	
	$id = (isset($_POST["textSent"]) && is_numeric($_POST["textSent"])) ? $_POST["textSent"] : 0;
	$class = isset($_GET["class"]) ? $_GET["class"] : "people";	
	$url = "https://swapi.dev/api/".$class."/".$id."/";	

	if($id != 0){
		$data = json_decode(file_get_contents($url));
		
		if($class == "people"){
			include_once '../class/people.php';
			$item = new People($db);
			$item->name = $data->name;
			$item->height = $data->height;
			$item->mass = $data->mass;
			$item->hair_color = $data->hair_color;
			$item->skin_color = $data->skin_color;
			$item->eye_color = $data->eye_color;
			$item->birth_year = $data->birth_year;
			$item->gender = $data->gender;
			$item->homeworld = $data->homeworld;
			$item->films = $data->films;
			$item->species = $data->species;
			$item->vehicles = $data->vehicles;
			$item->starships = $data->starships;
			$item->created = $data->created;
			$item->edited = $data->edited;
			$item->url = $data->url;
			$json = array();
			if($item->createPeople()){
				echo json_encode('People created successfully.');
			} else{
				echo json_encode('People could not be created.');
			} 
		}
		
		if($class == "planets"){
			include_once '../class/planets.php';
			$item = new Planets($db);
			$item->name = $data->name;
			$item->rotation_period = $data->rotation_period;
			$item->orbital_period = $data->orbital_period;
			$item->diameter = $data->diameter;
			$item->climate = $data->climate;
			$item->gravity = $data->gravity;
			$item->terrain = $data->terrain;
			$item->surface_water = $data->surface_water;
			$item->population = $data->population;
			$item->residents = $data->residents;
			$item->films = $data->films;
			$item->created = $data->created;
			$item->edited = $data->edited;
			$item->url = $data->url;
			
			$json = array();
			if($item->createPlanets()){
				echo json_encode('Planet created successfully.');
			} else{
				echo json_encode('Planet could not be created.');
			} 
		}
	}
	
?>