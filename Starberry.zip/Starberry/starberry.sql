-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 16, 2021 at 08:30 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `starberry`
--

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
CREATE TABLE IF NOT EXISTS `people` (
  `people_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `height` float NOT NULL,
  `mass` float NOT NULL,
  `hair_color` varchar(30) NOT NULL,
  `skin_color` varchar(30) NOT NULL,
  `eye_color` varchar(30) NOT NULL,
  `birth_year` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `homeworld` varchar(500) NOT NULL,
  `films` text NOT NULL,
  `species` text NOT NULL,
  `vehicles` text NOT NULL,
  `starships` text NOT NULL,
  `created` datetime NOT NULL,
  `edited` datetime NOT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`people_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`people_id`, `name`, `height`, `mass`, `hair_color`, `skin_color`, `eye_color`, `birth_year`, `gender`, `homeworld`, `films`, `species`, `vehicles`, `starships`, `created`, `edited`, `url`) VALUES
(12, 'Luke Skywalker', 172, 77, 'blond', 'fair', 'blue', '19BBY', 'male', 'https://swapi.dev/api/planets/1/', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/6\\/&quot;]', '[]', '[&quot;https:\\/\\/swapi.dev\\/api\\/vehicles\\/14\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/vehicles\\/30\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/12\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/22\\/&quot;]', '2014-12-09 13:50:52', '2014-12-20 21:17:57', 'https://swapi.dev/api/people/1/'),
(13, 'Obi-Wan Kenobi', 182, 77, 'auburn, white', 'fair', 'blue-gray', '57BBY', 'male', 'https://swapi.dev/api/planets/20/', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/4\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/5\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/6\\/&quot;]', '[]', '[&quot;https:\\/\\/swapi.dev\\/api\\/vehicles\\/38\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/48\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/59\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/64\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/65\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/74\\/&quot;]', '2014-12-10 16:16:29', '2014-12-20 21:17:50', 'https://swapi.dev/api/people/10/'),
(14, 'Chewbacca', 228, 112, 'brown', 'unknown', 'blue', '200BBY', 'male', 'https://swapi.dev/api/planets/14/', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/6\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/species\\/3\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/vehicles\\/19\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/10\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/starships\\/22\\/&quot;]', '2014-12-10 16:42:45', '2014-12-20 21:17:50', 'https://swapi.dev/api/people/13/'),
(15, 'Adi Gallia', 184, 50, 'none', 'dark', 'blue', 'unknown', 'female', 'https://swapi.dev/api/planets/9/', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/4\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/6\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/species\\/23\\/&quot;]', '[]', '[]', '2014-12-20 10:29:12', '2014-12-20 21:17:50', 'https://swapi.dev/api/people/55/');

-- --------------------------------------------------------

--
-- Table structure for table `planets`
--

DROP TABLE IF EXISTS `planets`;
CREATE TABLE IF NOT EXISTS `planets` (
  `planet_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `rotation_period` float NOT NULL,
  `orbital_period` float NOT NULL,
  `diameter` float NOT NULL,
  `climate` varchar(50) NOT NULL,
  `gravity` varchar(50) NOT NULL,
  `terrain` varchar(500) NOT NULL,
  `surface_water` varchar(50) NOT NULL,
  `population` varchar(50) NOT NULL,
  `residents` text NOT NULL,
  `films` text NOT NULL,
  `created` datetime NOT NULL,
  `edited` datetime NOT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`planet_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `planets`
--

INSERT INTO `planets` (`planet_id`, `name`, `rotation_period`, `orbital_period`, `diameter`, `climate`, `gravity`, `terrain`, `surface_water`, `population`, `residents`, `films`, `created`, `edited`, `url`) VALUES
(1, 'Tatooine', 23, 304, 10465, 'arid', '1 standard', 'desert', '1', '200000', '[&quot;https:\\/\\/swapi.dev\\/api\\/people\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/4\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/6\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/7\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/8\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/9\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/11\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/43\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/62\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/4\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/5\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/6\\/&quot;]', '2014-12-09 13:50:50', '2014-12-20 20:58:18', 'https://swapi.dev/api/planets/1/'),
(3, 'Utapau', 27, 351, 12900, 'temperate, arid, windy', '1 standard', 'scrublands, savanna, canyons, sinkholes', '0.9', '95000000', '[&quot;https:\\/\\/swapi.dev\\/api\\/people\\/83\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/6\\/&quot;]', '2014-12-10 12:49:01', '2014-12-20 20:58:18', 'https://swapi.dev/api/planets/12/');

-- --------------------------------------------------------

--
-- Table structure for table `starships`
--

DROP TABLE IF EXISTS `starships`;
CREATE TABLE IF NOT EXISTS `starships` (
  `starship_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `model` varchar(500) NOT NULL,
  `manufacturer` varchar(500) NOT NULL,
  `cost_in_credits` float NOT NULL,
  `length` float NOT NULL,
  `max_atmosphering_speed` varchar(50) NOT NULL,
  `crew` varchar(50) NOT NULL,
  `passengers` varchar(50) NOT NULL,
  `cargo_capacity` float NOT NULL,
  `consumables` varchar(50) NOT NULL,
  `hyperdrive_rating` float NOT NULL,
  `MGLT` float NOT NULL,
  `starship_class` varchar(500) NOT NULL,
  `pilots` text NOT NULL,
  `films` text NOT NULL,
  `created` datetime NOT NULL,
  `edited` datetime NOT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`starship_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `starships`
--

INSERT INTO `starships` (`starship_id`, `name`, `model`, `manufacturer`, `cost_in_credits`, `length`, `max_atmosphering_speed`, `crew`, `passengers`, `cargo_capacity`, `consumables`, `hyperdrive_rating`, `MGLT`, `starship_class`, `pilots`, `films`, `created`, `edited`, `url`) VALUES
(1, 'Star Destroyer', 'Imperial I-class Star Destroyer', 'Kuat Drive Yards', 150000000, 1, '975', '47,060', 'n/a', 36000000, '&quot;2 years&quot;', 0, 0, '&quot;Star Destroyer&quot;', '[]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;]', '2014-12-10 15:08:20', '2014-12-20 21:23:50', 'https://swapi.dev/api/starships/3/'),
(3, 'TIE Advanced x1', 'Twin Ion Engine Advanced x1', 'Sienar Fleet Systems', 0, 9.2, '1200', '1', '0', 150, '5 days', 1, 105, 'Starfighter', '[&quot;https:\\/\\/swapi.dev\\/api\\/people\\/4\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;]', '2014-12-12 11:21:33', '2014-12-20 21:23:50', 'https://swapi.dev/api/starships/13/'),
(4, 'X-wing', 'T-65 X-wing', 'Incom Corporation', 149999, 12.5, '1050', '1', '0', 110, '1 week', 1, 100, 'Starfighter', '[&quot;https:\\/\\/swapi.dev\\/api\\/people\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/9\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/18\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/19\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;]', '2014-12-12 11:19:05', '2014-12-20 21:23:50', 'https://swapi.dev/api/starships/12/');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE IF NOT EXISTS `vehicles` (
  `vehicle_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `model` varchar(500) NOT NULL,
  `manufacturer` varchar(500) NOT NULL,
  `cost_in_credits` float NOT NULL,
  `length` float NOT NULL,
  `max_atmosphering_speed` float NOT NULL,
  `crew` varchar(15) NOT NULL,
  `passengers` varchar(15) NOT NULL,
  `cargo_capacity` float NOT NULL,
  `consumables` varchar(20) NOT NULL,
  `vehicle_class` varchar(500) NOT NULL,
  `pilots` text NOT NULL,
  `films` text NOT NULL,
  `created` datetime NOT NULL,
  `edited` datetime NOT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`vehicle_id`, `name`, `model`, `manufacturer`, `cost_in_credits`, `length`, `max_atmosphering_speed`, `crew`, `passengers`, `cargo_capacity`, `consumables`, `vehicle_class`, `pilots`, `films`, `created`, `edited`, `url`) VALUES
(2, 'Snowspeeder', 't-47 airspeeder', 'Incom corporation', 0, 4.5, 650, '2', '0', 10, 'none', 'airspeeder', '[&quot;https:\\/\\/swapi.dev\\/api\\/people\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/people\\/18\\/&quot;]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;]', '2014-12-15 12:22:12', '2014-12-20 21:30:22', 'https://swapi.dev/api/vehicles/14/'),
(4, 'Storm IV Twin-Pod cloud car', 'Storm IV Twin-Pod', 'Bespin Motors', 75000, 7, 1500, '2', '0', 10, '1 day', 'repulsorcraft', '[]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;]', '2014-12-15 12:58:51', '2014-12-20 21:30:22', 'https://swapi.dev/api/vehicles/20/'),
(5, 'TIE/LN starfighter', 'Twin Ion Engine/Ln Starfighter', 'Sienar Fleet Systems', 0, 6.4, 1200, '1', '0', 65, '2 days', 'starfighter', '[]', '[&quot;https:\\/\\/swapi.dev\\/api\\/films\\/1\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/2\\/&quot;,&quot;https:\\/\\/swapi.dev\\/api\\/films\\/3\\/&quot;]', '2014-12-10 16:33:53', '2014-12-20 21:30:22', 'https://swapi.dev/api/vehicles/8/');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
