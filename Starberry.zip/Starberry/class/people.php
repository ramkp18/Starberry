<?php
    class People{

        // Connection
        private $conn;

        // Table
        private $db_table = "people";

        // Columns
        public $id;
        public $name;
        public $height;
        public $mass;
        public $hair_color;
        public $skin_color;
        public $eye_color;
        public $birth_year;
        public $gender;
        public $homeworld;
        public $films;
        public $species;
        public $vehicles;
        public $starships;
        public $created;
        public $edited;
        public $url;
        public $filed;
        public $value;
		
        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getPeoples(){
            $sqlQuery = "SELECT `people_id`,`name`,`height`,`mass`,`hair_color`,`skin_color`,`eye_color`,`birth_year`,`gender`,`homeworld`,`films`,`species`,`vehicles`,`starships`,`created`,`edited`,`url` FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createPeople(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        name = :name, 
                        height = :height, 
                        mass = :mass, 
                        hair_color = :hair_color, 
                        skin_color = :skin_color, 
                        eye_color = :eye_color, 
                        birth_year = :birth_year, 
                        gender = :gender, 
                        homeworld = :homeworld, 
                        films = :films, 
                        species = :species, 
                        vehicles = :vehicles, 
                        starships = :starships, 
                        created = :created, 
                        edited = :edited, 
                        url = :url";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->height=htmlspecialchars(strip_tags($this->height));
            $this->mass=htmlspecialchars(strip_tags($this->mass));
            $this->hair_color=htmlspecialchars(strip_tags($this->hair_color));
            $this->skin_color=htmlspecialchars(strip_tags($this->skin_color));
            $this->eye_color=htmlspecialchars(strip_tags($this->eye_color));
            $this->birth_year=htmlspecialchars(strip_tags($this->birth_year));
            $this->gender=htmlspecialchars(strip_tags($this->gender));
            $this->homeworld=htmlspecialchars(strip_tags($this->homeworld));
            $this->films=htmlspecialchars(strip_tags(json_encode($this->films)));
            $this->species=htmlspecialchars(strip_tags(json_encode($this->species)));
            $this->vehicles=htmlspecialchars(strip_tags(json_encode($this->vehicles)));
            $this->starships=htmlspecialchars(strip_tags(json_encode($this->starships)));
            $this->created=htmlspecialchars(strip_tags($this->created));
            $this->edited=htmlspecialchars(strip_tags($this->edited));
            $this->url=htmlspecialchars(strip_tags($this->url));
        
            // bind data
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":height", $this->height);
            $stmt->bindParam(":mass", $this->mass);
            $stmt->bindParam(":hair_color", $this->hair_color);
            $stmt->bindParam(":skin_color", $this->skin_color);
            $stmt->bindParam(":eye_color", $this->eye_color);
            $stmt->bindParam(":birth_year", $this->birth_year);
            $stmt->bindParam(":gender", $this->gender);
            $stmt->bindParam(":homeworld", $this->homeworld);
            $stmt->bindParam(":films", $this->films);
            $stmt->bindParam(":species", $this->species);
            $stmt->bindParam(":vehicles", $this->vehicles);
            $stmt->bindParam(":starships", $this->starships);
            $stmt->bindParam(":created", $this->created);
            $stmt->bindParam(":edited", $this->edited);
            $stmt->bindParam(":url", $this->url);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // READ single
        public function getSinglePeople(){
            $sqlQuery = "SELECT `people_id`,`name`,`height`,`mass`,`hair_color`,`skin_color`,`eye_color`,`birth_year`,`gender`,`homeworld`,`films`,`species`,`vehicles`,`starships`,`created`,`edited`,`url`
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       people_id  = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->people_id = $dataRow['people_id'];
            $this->name = $dataRow['name'];
            $this->height = $dataRow['height'];
            $this->mass = $dataRow['mass'];
            $this->hair_color = $dataRow['hair_color'];
            $this->skin_color = $dataRow['skin_color'];
            $this->eye_color = $dataRow['eye_color'];
            $this->birth_year = $dataRow['birth_year'];
            $this->gender = $dataRow['gender'];
            $this->homeworld = $dataRow['homeworld'];
            $this->films = str_replace("\\","",$dataRow['films']);
            $this->species = str_replace("\\","",$dataRow['species']);
            $this->vehicles = str_replace("\\","",$dataRow['vehicles']);
            $this->starships = str_replace("\\","",$dataRow['starships']);
            $this->created = $dataRow['created'];
            $this->edited = $dataRow['edited'];
            $this->url = $dataRow['url'];
			
        }        

        // UPDATE
        public function updatePeople(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        $this->field = :value
                    WHERE 
                        people_id = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
       
            $this->field=htmlspecialchars(strip_tags($this->value));
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            // bind data
            $stmt->bindParam(":value", $this->value);
            $stmt->bindParam(":id", $this->id);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deletePeople(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE people_id  = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>