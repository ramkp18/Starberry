<?php
    class Vehicles{

        // Connection
        private $conn;

        // Table
        private $db_table = "vehicles";

        // Columns
        public $id;
        public $name;
        public $model;
        public $manufacturer;
        public $cost_in_credits;
        public $length;
        public $max_atmosphering_speed;
        public $crew;
        public $passengers;
        public $cargo_capacity;
        public $consumables;
        public $vehicle_class;
        public $pilots;
        public $films;
        public $created;
        public $edited;
        public $url;
        public $filed;
        public $value;
		
        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getVehicles(){
            $sqlQuery = "SELECT `id`,`name`,`model`,`manufacturer`,`cost_in_credits`,`length`,`max_atmosphering_speed`,`crew`,`passengers`,`cargo_capacity`,`consumables`,`vehicle_class`,`pilots`,`films`,`created`,`edited`,`url` FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createVehicles(){
             $stmt = $this->conn->prepare("SELECT COUNT(`id`) total FROM " . $this->db_table . " WHERE id  = ? LIMIT 0,1");
			$stmt->bindParam(1,$this->id);
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_ASSOC);
			
			if($data['total'] == 0){
				$sqlQuery = "INSERT INTO
							". $this->db_table ."
						SET
							id = :id, 
							name = :name, 
							model = :model, 
							manufacturer = :manufacturer, 
							cost_in_credits = :cost_in_credits, 
							length = :length, 
							max_atmosphering_speed = :max_atmosphering_speed, 
							crew = :crew, 
							passengers = :passengers, 
							cargo_capacity	 = :cargo_capacity, 
							consumables = :consumables,
							vehicle_class = :vehicle_class, 
							pilots = :pilots, 
							films = :films, 
							created = :created, 
							edited = :edited, 
							url = :url";
			
				$stmt = $this->conn->prepare($sqlQuery);
			
				// sanitize
				$this->id=htmlspecialchars(strip_tags($this->id));
				$this->name=htmlspecialchars(strip_tags($this->name));
				$this->model=htmlspecialchars(strip_tags($this->model));
				$this->manufacturer=htmlspecialchars(strip_tags($this->manufacturer));
				$this->cost_in_credits=htmlspecialchars(strip_tags($this->cost_in_credits));
				$this->length=htmlspecialchars(strip_tags($this->length));
				$this->max_atmosphering_speed=htmlspecialchars(strip_tags($this->max_atmosphering_speed));
				$this->crew=htmlspecialchars(strip_tags($this->crew));
				$this->passengers=htmlspecialchars(strip_tags($this->passengers));
				$this->cargo_capacity	=htmlspecialchars(strip_tags($this->cargo_capacity	));
				$this->consumables=htmlspecialchars(strip_tags($this->consumables));
				$this->vehicle_class=htmlspecialchars(strip_tags($this->vehicle_class));
				$this->pilots=htmlspecialchars(strip_tags(json_encode($this->pilots)));
				$this->films=htmlspecialchars(strip_tags(json_encode($this->films)));
				$this->created=htmlspecialchars(strip_tags($this->created));
				$this->edited=htmlspecialchars(strip_tags($this->edited));
				$this->url=htmlspecialchars(strip_tags($this->url));
		   
				// bind data
				$stmt->bindParam(":id", $this->id);
				$stmt->bindParam(":name", $this->name);
				$stmt->bindParam(":model", $this->model);
				$stmt->bindParam(":manufacturer", $this->manufacturer);
				$stmt->bindParam(":cost_in_credits", $this->cost_in_credits);
				$stmt->bindParam(":length", $this->length);
				$stmt->bindParam(":max_atmosphering_speed", $this->max_atmosphering_speed);
				$stmt->bindParam(":crew", $this->crew);
				$stmt->bindParam(":passengers", $this->passengers);
				$stmt->bindParam(":cargo_capacity", $this->cargo_capacity);
				$stmt->bindParam(":consumables", $this->consumables);
				$stmt->bindParam(":vehicle_class", $this->vehicle_class);            
				$stmt->bindParam(":pilots", $this->pilots);
				$stmt->bindParam(":films", $this->films);
				$stmt->bindParam(":created", $this->created);
				$stmt->bindParam(":edited", $this->edited);
				$stmt->bindParam(":url", $this->url);
			 
				if($stmt->execute()){
				   return true;
				}
            }
            return false;
        }

        // READ single
        public function getSingleVehicle(){
            $sqlQuery = "SELECT `id`,`name`,`model`,`manufacturer`,`cost_in_credits`,`length`,`max_atmosphering_speed`,`crew`,`passengers`,`cargo_capacity`,`consumables`,`vehicle_class`,`pilots`,`films`,`created`,`edited`,`url`
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       id  = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->vehicle_id  = $dataRow['id'];
            $this->name = $dataRow['name'];
            $this->model = $dataRow['model'];
            $this->manufacturer = $dataRow['manufacturer'];
            $this->cost_in_credits = $dataRow['cost_in_credits'];
            $this->length = $dataRow['length'];
            $this->max_atmosphering_speed = $dataRow['max_atmosphering_speed'];
            $this->crew = $dataRow['crew'];
            $this->passengers = $dataRow['passengers'];
            $this->cargo_capacity	 = $dataRow['cargo_capacity'];
            $this->consumables = $dataRow['consumables'];
            $this->vehicle_class = $dataRow['vehicle_class'];
            $this->films = str_replace("\\","",$dataRow['films']);
            $this->pilots = str_replace("\\","",$dataRow['pilots']);
            $this->created = $dataRow['created'];
            $this->edited = $dataRow['edited'];
            $this->url = $dataRow['url'];
			
        }        

        // UPDATE
        public function updateVehicle(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        $this->field = :value
                    WHERE 
                        id  = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
       
            $this->field=htmlspecialchars(strip_tags($this->value));
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            // bind data
            $stmt->bindParam(":value", $this->value);
            $stmt->bindParam(":id", $this->id);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deleteVehicle(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>