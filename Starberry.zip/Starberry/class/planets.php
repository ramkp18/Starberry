<?php
    class Planets{

        // Connection
        private $conn;

        // Table
        private $db_table = "planets";

        // Columns
        public $id;
        public $name;
        public $rotation_period;
        public $orbital_period;
        public $climate;
        public $gravity;
        public $terrain;
        public $surface_water;
        public $population;
        public $residents;
        public $films;
        public $vehicles;
        public $starships;
        public $created;
        public $edited;
        public $url;
		
        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getPlanets(){
            $sqlQuery = "SELECT `id`,`name`,`rotation_period`,`orbital_period`,`diameter`,`climate`,`gravity`,`terrain`,`surface_water`,`population`,`residents`,`films`,`created`,`edited`,`url` FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createPlanets(){
            $stmt = $this->conn->prepare("SELECT COUNT(`id`) total FROM " . $this->db_table . " WHERE id  = ? LIMIT 0,1");
			$stmt->bindParam(1,$this->id);
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_ASSOC);
			
			if($data['total'] == 0){
				$sqlQuery = "INSERT INTO
							". $this->db_table ."
						SET
							id = :id, 
							name = :name, 
							rotation_period = :rotation_period, 
							orbital_period = :orbital_period, 
							diameter = :diameter, 
							climate = :climate, 
							gravity = :gravity, 
							terrain = :terrain, 
							surface_water = :surface_water, 
							population = :population, 
							residents = :residents, 
							films = :films, 
							created = :created, 
							edited = :edited, 
							url = :url";
			
				$stmt = $this->conn->prepare($sqlQuery);
			
				// sanitize
				$this->id=htmlspecialchars(strip_tags($this->id));
				$this->name=htmlspecialchars(strip_tags($this->name));
				$this->rotation_period=htmlspecialchars(strip_tags($this->rotation_period));
				$this->orbital_period=htmlspecialchars(strip_tags($this->orbital_period));
				$this->diameter=htmlspecialchars(strip_tags($this->diameter));
				$this->climate=htmlspecialchars(strip_tags($this->climate));
				$this->gravity=htmlspecialchars(strip_tags($this->gravity));
				$this->terrain=htmlspecialchars(strip_tags($this->terrain));
				$this->surface_water=htmlspecialchars(strip_tags($this->surface_water));
				$this->population=htmlspecialchars(strip_tags($this->population));
				$this->residents=htmlspecialchars(strip_tags(json_encode($this->residents)));
				$this->films=htmlspecialchars(strip_tags(json_encode($this->films)));
				$this->created=htmlspecialchars(strip_tags($this->created));
				$this->edited=htmlspecialchars(strip_tags($this->edited));
				$this->url=htmlspecialchars(strip_tags($this->url));
			
				// bind data
				$stmt->bindParam(":id", $this->id);
				$stmt->bindParam(":name", $this->name);
				$stmt->bindParam(":rotation_period", $this->rotation_period);
				$stmt->bindParam(":orbital_period", $this->orbital_period);
				$stmt->bindParam(":diameter", $this->diameter);
				$stmt->bindParam(":climate", $this->climate);
				$stmt->bindParam(":gravity", $this->gravity);
				$stmt->bindParam(":terrain", $this->terrain);
				$stmt->bindParam(":surface_water", $this->surface_water);
				$stmt->bindParam(":population", $this->population);
				$stmt->bindParam(":residents", $this->residents);
				$stmt->bindParam(":films", $this->films);
				$stmt->bindParam(":created", $this->created);
				$stmt->bindParam(":edited", $this->edited);
				$stmt->bindParam(":url", $this->url);
			
				if($stmt->execute()){
				   return true;
				}
			}
            return false;
        }

        // READ single
        public function getSinglePlanet(){
            $sqlQuery = "SELECT `id`,`name`,`rotation_period`,`orbital_period`,`diameter`,`climate`,`gravity`,`terrain`,`surface_water`,`population`,`residents`,`films`,`created`,`edited`,`url`
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       id   = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
           
            $this->planet_id  = $dataRow['id'];
            $this->name = $dataRow['name'];
            $this->rotation_period = $dataRow['rotation_period'];
            $this->orbital_period = $dataRow['orbital_period'];
            $this->diameter = $dataRow['diameter'];
            $this->climate = $dataRow['climate'];
            $this->gravity = $dataRow['gravity'];
            $this->terrain = $dataRow['terrain'];
            $this->surface_water = $dataRow['surface_water'];
            $this->population = $dataRow['population'];
            $this->residents = $dataRow['residents'];
            $this->films = $dataRow['films'];
            $this->created = $dataRow['created'];
            $this->edited = $dataRow['edited'];
            $this->url = $dataRow['url'];
			
        }        

        // UPDATE
        public function updatePlanet(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        $this->field = :value
                    WHERE 
                        id = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
       
            $this->field=htmlspecialchars(strip_tags($this->value));
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            // bind data
            $stmt->bindParam(":value", $this->value);
            $stmt->bindParam(":id", $this->id);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deletePlanet(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id  = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>